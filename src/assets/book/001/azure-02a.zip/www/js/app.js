// (1) 起動時の処理
var table;
ons.ready(function() {
	// Azureの接続準備
	var azure = new WindowsAzure.MobileServiceClient("App ServiceのURL");
	table = azure.getTable("userComments");
	showComments();
});

// (2) コメント取得処理
function showComments() {


}

// １件分のメモを表すHTML要素を作成
function createListItem(data) {
	var style = "";
	var clickEvent = "";
	
	// 自分の書き込みだった場合
    if(data.uuid == device.uuid) {
    	style = "color:blue";
    	clickEvent = "onclick='showEditPage(" + JSON.stringify(data) + ")'";
    }	
    
    var item = "<ons-list-item modifier='longdivider' class='item' " + clickEvent + ">"
            + "<p class='comment' style='" + style + "'>" + data.comment + "</p>"
        	+ "</ons-list-item>";
    return item;
}

// 追加ボタンを押したときの処理
function showNewPage() {
	document.getElementById("navi").pushPage("new.html");
}

// (3) コメント追加処理
function addComment() {


}

// 編集ボタンを押したときの処理
function showEditPage(data) {
	document.getElementById("navi").pushPage("edit.html")
	.then(function() {
		document.getElementById("edit-comment").value = data.comment;
		
	    // 保存ボタンを押した時の処理
	    document.getElementById("edit-save-btn").onclick = function() {
	    	editComment(data.id);
	    };
	
	    // 削除アイコンを押した時の処理
	    document.getElementById("del-btn").onclick = function() {
	     	delComment(data.id);
	    };
	});
}

// (4) コメント編集処理
function editComment(id) {


}

// (5) コメント削除処理
function delComment(id) {


}