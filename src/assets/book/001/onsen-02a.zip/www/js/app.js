// 初期処理
ons.ready(showListData);

// 一覧ページを表示
function showListData() {
    
    
}

// 詳細ページを表示
function onItemClick(item) {
    
    
}
