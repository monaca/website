// 一覧ページが開いたときの処理
document.addEventListener("init", function(event) {
    if (event.target.id == "list-page") {
        loadData();
    }
});

// 一覧ページにデータを読み込む
function loadData() {
    
    
}

// 詳細ページへ移動
function onItemClick(item) {
    
    
}
